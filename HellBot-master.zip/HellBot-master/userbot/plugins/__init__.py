from userbot import darkdef


darkmusic = darkdef.darkmusic 
darkmusicvideo = darkdef.darkmusicvideo

